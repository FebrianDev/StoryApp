package com.febrian.storyapp.utils

object Constant {
    const val sharedPreferences = "sharedPreferences"

    const val TOKEN = "TOKEN"

    const val ID_STORY = "ID_STORY"
}