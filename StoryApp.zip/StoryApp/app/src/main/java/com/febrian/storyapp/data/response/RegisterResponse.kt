package com.febrian.storyapp.data.response

data class RegisterResponse(
    var error: Boolean? = null,
    var message: String? = null
)