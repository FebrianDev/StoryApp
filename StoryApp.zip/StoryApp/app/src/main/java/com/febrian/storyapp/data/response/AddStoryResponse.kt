package com.febrian.storyapp.data.response

data class AddStoryResponse(
    var error: Boolean? = null,
    var message: String? = null
)