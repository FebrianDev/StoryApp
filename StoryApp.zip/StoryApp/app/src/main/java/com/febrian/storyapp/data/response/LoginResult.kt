package com.febrian.storyapp.data.response

data class LoginResult(
    var userId: String? = null,
    var name: String? = null,
    var token: String? = null
)
