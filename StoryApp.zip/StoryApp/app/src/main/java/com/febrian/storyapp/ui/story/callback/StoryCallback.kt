package com.febrian.storyapp.ui.story.callback

interface StoryCallback {
    fun getDetail(id: String)
}